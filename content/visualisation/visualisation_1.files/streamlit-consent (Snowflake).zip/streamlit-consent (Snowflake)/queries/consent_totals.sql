select * from snowplow_web_consent_totals
