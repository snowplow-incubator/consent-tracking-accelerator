select
  'within 5 sec' as base,
  count(case when cmp_load_time < 5 then 1 end) as value
from snowplow_web_consent_cmp_stats

union all

select
  'between 5 and 30 seconds' as base,
  count(case when cmp_load_time < 30 and cmp_load_time >= 5 then 1 end) as value
from snowplow_web_consent_cmp_stats

union all

select
  'between 30 and 60 seconds' as base,
  count(case when cmp_load_time <60 and cmp_load_time >= 30 then 1 end) as value
from snowplow_web_consent_cmp_stats

union all

select
  'after 1 min or more' as base,
  count(case when cmp_load_time >= 60 then 1 end) as value
from snowplow_web_consent_cmp_stats
